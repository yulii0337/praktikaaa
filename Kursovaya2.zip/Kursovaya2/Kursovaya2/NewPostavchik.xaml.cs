﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для NewPostavchik.xaml
    /// </summary>
    public partial class NewPostavchik : Window
    {
        Enti5 database = new Enti5();
        public NewPostavchik()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();

            // Вызов метода для загрузки данных в ComboBox  
            AdresToComboBox();
   
        }

        private Enti5 Enti5;
        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }

        //КОМБО Страна
        private void AdresToComboBox()
        {
            try
            {
                // Подключаение к Entity Framework и получение данных из таблиц
                using (var context = new Enti5())  // Enti5 это контекст данных
                {
                    //запрос, соединяя таблицы 'категория_товара' и 'товары' по ID_товара
                    var adres = context.адрес
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование товара
                    CmbBoxAdres.ItemsSource = adres;    // Устанавливает источник данных
                    CmbBoxAdres.DisplayMemberPath = "ID_адреса";  // Указывает, что в ComboBox будет отображаться наименование_товара
                    CmbBoxAdres.SelectedValuePath = "ID_адреса";            // Указывает, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }




        private void NazadBttn_Click(object sender, RoutedEventArgs e)
        {
            Postavshiki_two Postavshiki_two = new Postavshiki_two();
            Postavshiki_two.Show();
            this.Close();
        }

        private void RegistrBttn_Click(object sender, RoutedEventArgs e)
        {
            // Проверяет, что все текстовые поля и ComboBox заполнены
            if (string.IsNullOrEmpty(TxtBoxNaimen.Text) ||
                string.IsNullOrEmpty(TxtBoxPochta.Text) ||
                string.IsNullOrEmpty(TxtBoxNumberPhone.Text) ||
                string.IsNullOrEmpty(TxtBoxInn.Text) ||
                string.IsNullOrEmpty(TxtBoxFamilia.Text) ||
                string.IsNullOrEmpty(TxtBoxName.Text) ||
                string.IsNullOrEmpty(TxtBoxGdePapa.Text) ||
                CmbBoxAdres.SelectedItem == null) // Проверка на пустое значение ComboBox
            {
                MessageBox.Show("Пожалуйста, заполните все поля!");
                return;
            }

            // Проверка ИНН на длину и цифры
            if (TxtBoxInn.Text.Length != 12 || !TxtBoxInn.Text.All(char.IsDigit))
            {
                MessageBox.Show("ИНН должен быть 12 цифр!");
                return;
            }

            // Проверка номера телефона на длину и цифры
            if (TxtBoxNumberPhone.Text.Length != 11 || !TxtBoxNumberPhone.Text.All(char.IsDigit))
            {
                MessageBox.Show("Номер телефона должен содержать 11 цифр!");
                return;
            }

            try
            {
                // Использует контекст для работы с базой данных
                using (var context = new Enti5())
                {
                    // Получает выбранный адрес из ComboBox
                    var selectedAdres = CmbBoxAdres.SelectedItem as адрес;

                    // Создает новый объект поставщика
                    var newPostavshik = new поставщики()
                    {
                        наименование_поставщика = TxtBoxNaimen.Text,
                        почта = TxtBoxPochta.Text,
                        номер_телефона = TxtBoxNumberPhone.Text,
                        ИНН = TxtBoxInn.Text,
                        фамилия = TxtBoxFamilia.Text,
                        имя = TxtBoxName.Text,
                        отчество = TxtBoxGdePapa.Text,
                        ID_адреса = selectedAdres.ID_адреса // Присваивает ID адреса из ComboBox
                    };

                    // Добавляет нового поставщика в таблицу поставщиков
                    context.поставщики.Add(newPostavshik);

                    // Сохраняет изменения в базе данных
                    context.SaveChanges();
                }

              
                Postavshiki_two Postavshiki_two = new Postavshiki_two();
                Postavshiki_two.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                // В случае ошибки  сообщение
                MessageBox.Show($"Произошла ошибка при сохранении данных: {ex.Message}");
            }
        }
    }
}
