﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для Glavnaya_two.xaml
    /// </summary>
    public partial class Glavnaya_two : Window
    {
        public Glavnaya_two()
        {
            InitializeComponent(); 
            WindowState = WindowState.Maximized;
        }

        //переход на окно Главная
        private void LabelGlavnaya_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Glavnaya_two Glavnaya_two = new Glavnaya_two();
            Glavnaya_two.Show();
            this.Close();
        }


        //переход на окно товары два
        private void LabelSotrudnik_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Sotrudniki Sotrudniki = new Sotrudniki();
            Sotrudniki.Show();
            this.Close();
        }



        //переход на окно Поставщики два
        private void LabelPostavshiki_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Postavshiki_two Postavshiki_two = new Postavshiki_two();
            Postavshiki_two.Show();
            this.Close();
        }
    }
}
