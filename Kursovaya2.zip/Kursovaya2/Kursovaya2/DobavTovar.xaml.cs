﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для DobavTovar.xaml
    /// </summary>
    public partial class DobavTovar : Window
    {

        Enti5 database = new Enti5();

        public DobavTovar()
        {
            InitializeComponent(); WindowState = WindowState.Maximized;
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();

            // Вызов метода для загрузки данных в ComboBox категории
            KategoriaToComboBox();

            // Вызов метода для загрузки данных в ComboBox пол
            PolToComboBox();

            // Вызов метода для загрузки данных в ComboBox пол
           SizeEuToComboBox();

            // Вызов метода для загрузки данных в ComboBox пол
            SizeRussToComboBox();

            // Вызов метода для загрузки данных в ComboBox пол 
            ColorToComboBox();

            // Вызов метода для загрузки данных в ComboBox пол 
            PostavchikiToComboBox();
        }


        private Enti5 Enti5;



        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }


        //// Метод для загрузки данных из БД в ComboBox Категории
        private void KategoriaToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это   контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'категория_товара' и 'товары' по ID_товара
                    var tovari = context.категория_товара
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование товара
                    CmbBoxKategoria.ItemsSource = tovari;    // Устанавливаем источник данных
                    CmbBoxKategoria.DisplayMemberPath = "наименование";  // Указываем, что в ComboBox будет отображаться наименование_товара
                    CmbBoxKategoria.SelectedValuePath = "ID_категории_товара";            // Указываем, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        //// Метод для загрузки данных из БД в ComboBox пол
        private void PolToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это   контекст данных
                {
                    var tovari = context.пол
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование товара
                    CmbBoxPol.ItemsSource = tovari;    // Устанавливаем источник данных
                    CmbBoxPol.DisplayMemberPath = "наименование";  // Указываем, что в ComboBox будет отображаться наименование_товара
                    CmbBoxPol.SelectedValuePath = "ID_пола";            // Указываем, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        //// Метод для загрузки данных из БД в ComboBox размеры европейский
        private void SizeEuToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это   контекст данных
                {
                   
                    var tovari = context.размеры
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование товара
                    CmbBoxSizeEu.ItemsSource = tovari;    // Устанавливаем источник данных
                    CmbBoxSizeEu.DisplayMemberPath = "европейский";  // Указываем, что в ComboBox будет отображаться наименование_товара
                    CmbBoxSizeEu.SelectedValuePath = "ID_размера_одежды";            // Указываем, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        //// Метод для загрузки данных из БД в ComboBox размеры российский
        private void SizeRussToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это   контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'размеры' и 'товары' по ID_товара
                    var tovari = context.размеры
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование товара
                    CmbBoxSizeRuss.ItemsSource = tovari;    // Устанавливаем источник данных
                    CmbBoxSizeRuss.DisplayMemberPath = "российский";  // Указываем, что в ComboBox будет отображаться наименование_товара
                    CmbBoxSizeRuss.SelectedValuePath = "ID_размера_одежды";            // Указываем, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        //// Метод для загрузки данных из БД в ComboBox цвет
        private void ColorToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это   контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'цвет' и 'товары' по ID_товара
                    var tovari = context.цвет
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование цвета
                    CmbBoxColor.ItemsSource = tovari;    // Устанавливаем источник данных
                    CmbBoxColor.DisplayMemberPath = "наименование";  // Указываем, что в ComboBox будет отображаться наименование_цвета
                    CmbBoxColor.SelectedValuePath = "ID_цвета";            // Указываем, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        //// Метод для загрузки данных из БД в ComboBox поставщики
        private void PostavchikiToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это   контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'поставщики' и 'товары' по ID_товара
                    var tovari = context.поставщики
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование цвета
                    CmbBoxPostavka.ItemsSource = tovari;    // Устанавливаем источник данных
                    CmbBoxPostavka.DisplayMemberPath = "ID_поставщиков";  // Указываем, что в ComboBox будет отображаться наименование_цвета
                    CmbBoxPostavka.SelectedValuePath = "ID_поставщиков";            // Указываем, что значение выбранного элемента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }


        //добавить
        // Метод для загрузки данных в ComboBox (категории, пол, размеры, цвет, поставщики)
        private void LoadComboBoxData()
        {
            try
            {
                using (var context = new Enti5()) // создает контекст для работы с БД
                {
                    // Загружает данные для ComboBox
                    CmbBoxKategoria.ItemsSource = context.категория_товара.ToList();
                    CmbBoxPol.ItemsSource = context.пол.ToList();
                    CmbBoxSizeEu.ItemsSource = context.размеры.ToList();
                    CmbBoxSizeRuss.ItemsSource = context.размеры.ToList(); // Пример для российского размера
                    CmbBoxColor.ItemsSource = context.цвет.ToList();
                    CmbBoxPostavka.ItemsSource = context.поставщики.ToList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных для ComboBox: {ex.Message}");
            }
        }

        private void TxtBoxPrice_PreviewTextInput(object sender, TextCompositionEventArgs e)
{
    // Проверяет, является ли введенный символ цифрой
    if (!Char.IsDigit(e.Text, 0)) 
    {
        // Если это не цифра, отменяем ввод
        e.Handled = true;
    }
}

        // Обработчик кнопки для сохранения данных
        private void RegistrBttn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(TxtBoxPrice.Text) || TxtBoxPrice.Text.Length > 6 || !TxtBoxPrice.Text.All(Char.IsDigit))
            {
                // Если введенные данные некорректны, вывод сообщения
                MessageBox.Show("Введите корректную цену (только цифры и не более 6 символов).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            //для артикула ограничение
            if (string.IsNullOrEmpty(TxtBoxArticul.Text) || TxtBoxArticul.Text.Length > 8 || !TxtBoxArticul.Text.All(Char.IsDigit))
            {
                // Если введенные данные некорректны, вывод сообщения
                MessageBox.Show("Введите корректный артикул (только цифры и не более 8 символов).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            //для описания ограничение
            if (TxtBoxOpisanie.Text.Length > 445)
            {
                // Если длина текста больше 445 символов, вывод сообщения
                MessageBox.Show("Описание не может содержать более 445 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            //для состав ограничение
            if (TxtBoxSostav.Text.Length > 445)
            {
                // Если длина текста больше 445 символов, вывод сообщения
                MessageBox.Show("Состав не может содержать более 445 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            // Проверка на пустые поля
            string errorMessage = string.Empty;

            if (string.IsNullOrEmpty(TxtBoxName.Text)) errorMessage += "Наименование товара не заполнено.\n";
            if (string.IsNullOrEmpty(TxtBoxArticul.Text)) errorMessage += "Артикул не заполнен.\n";
            if (string.IsNullOrEmpty(TxtBoxPrice.Text)) errorMessage += "Цена не заполнена.\n";
            if (CmbBoxKategoria.SelectedItem == null) errorMessage += "Категория не выбрана.\n";
            if (CmbBoxPol.SelectedItem == null) errorMessage += "Пол не выбран.\n";
            if (CmbBoxSizeEu.SelectedItem == null) errorMessage += "Европейский размер не выбран.\n";
            if (CmbBoxSizeRuss.SelectedItem == null) errorMessage += "Российский размер не выбран.\n";
            if (CmbBoxColor.SelectedItem == null) errorMessage += "Цвет не выбран.\n";
            if (CmbBoxPostavka.SelectedItem == null) errorMessage += "Поставщик не выбран.\n";

            // Если есть ошибки, вывод их
            if (!string.IsNullOrEmpty(errorMessage))
            {
                MessageBox.Show($"Пожалуйста, заполните все поля:\n{errorMessage}");
                return;
            }


            // Если все поля заполнены, создает новый объект для добавления в БД
            try
            {
                using (var context = new Enti5())
                {
                    // создает новый товар и заполнение его данными
                    var newTovar = new товары
                    {
                        наименование_товара = TxtBoxName.Text,
                        артикул = TxtBoxArticul.Text,
                        цена = (double)Convert.ToDecimal(TxtBoxPrice.Text),
                        описание = TxtBoxOpisanie.Text,
                        состав = TxtBoxSostav.Text,
                        ID_категории_товара = ((категория_товара)CmbBoxKategoria.SelectedItem).ID_категории_товара,
                        ID_пола = ((пол)CmbBoxPol.SelectedItem).ID_пола,
                        ID_размера_одежды = ((размеры)CmbBoxSizeEu.SelectedItem).ID_размера_одежды, // Для европейского размера
                        ID_цвета = ((цвет)CmbBoxColor.SelectedItem).ID_цвета,
                        ID_поставщиков = ((поставщики)CmbBoxPostavka.SelectedItem).ID_поставщиков
                    };

                    // Добавляет товар в контекст и сохраняем изменения
                    context.товары.Add(newTovar);
                    context.SaveChanges();
                }

                Tovari DobavTovar = new Tovari();
                DobavTovar.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки при добавлении товара
                MessageBox.Show($"Ошибка при добавлении товара: {ex.Message}");
            }
        }

        //назад DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework


        private void NazadBttn_Click_1(object sender, RoutedEventArgs e)
        {
            Tovari DobavTovar = new Tovari();
            DobavTovar.Show();
            this.Close();
        }
    }
}
