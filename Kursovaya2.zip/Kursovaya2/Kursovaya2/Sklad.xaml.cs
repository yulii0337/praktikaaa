﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Office.Interop.Word;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для Sklad.xaml
    /// </summary>
    public partial class Sklad 
    {
        Enti5 database = new Enti5();

        public Sklad()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();
            DtGrdSklad.ItemsSource = Enti5.товары_на_складе.ToList();
            LoadData();

            // Вызов метода для загрузки данных в ComboBox категории
            SkladToComboBox();

            // Вызов метода для загрузки данных в ComboBox категории
            TovarToComboBox();
        }
        private Enti5 Enti5;


        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }



        // Метод для загрузки всех данных из базы данных ПОИСК
        private void LoadData()
        {
            // Загружает все товары на складе
            DtGrdSklad.ItemsSource = Enti5.товары_на_складе.ToList();
        }

        // Обработчик события для кнопки поиска
        private void BttnSearch_Click(object sender, RoutedEventArgs e)
        {
            // Получает текст из TextBox и преобразует в нижний регистр для нечувствительного поиска
            string searchText = TBSearch.Text.ToLower();

            // Если текст пустой или состоит только из пробелов, показывает все данные
            if (string.IsNullOrWhiteSpace(searchText))
            {
                LoadData(); // Загружает все данные
            }
            else
            {
                // Если текст не пустой, выполняет фильтрацию данных
                var filteredData = Enti5.товары_на_складе
                    .Where(t => t.склад.ID_склада.ToString().ToLower().Contains(searchText) ||  // Поиск по ID склада
                                t.склад.наименование.ToLower().Contains(searchText) || // Поиск по наименованию склада
                                t.товары.наименование_товара.ToLower().Contains(searchText) || // Поиск по наименованию товара
                                t.товары.ID_товара.ToString().Contains(searchText) || // Поиск по наименованию товара
                                t.колличество_товара.ToString().ToLower().Contains(searchText)) // Поиск по количеству товара
                    .ToList(); // Преобразует в список

                // Обновляет ItemsSource для DataGrid с отфильтрованными данными
                DtGrdSklad.ItemsSource = filteredData;
            }
        }




        //// Метод для загрузки данных из БД в ComboBox склад
        private void SkladToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это ваш контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'склад' и 'склад' по ID_товара
                    var sklad = context.склад
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование цвета
                    CmbBoxSklad.ItemsSource = sklad;    // Устанавливает источник данных
                    CmbBoxSklad.DisplayMemberPath = "ID_склада";  // Указывает, что в ComboBox будет отображаться наименование_цвета
                    CmbBoxSklad.SelectedValuePath = "ID_склада";            // Указывает, что значение выбранного элетента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }


        //// Метод для загрузки данных из БД в ComboBox товары
        private void TovarToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var context = new Enti5())  // Enti5 - это ваш контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'склад' и 'товары' по ID_товара
                    var tovari = context.товары
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование цвета
                    CmbBoxTovara.ItemsSource = tovari;    // Устанавливает источник данных
                    CmbBoxTovara.DisplayMemberPath = "ID_товара";  // Указывает, что в ComboBox будет отображаться наименование_цвета
                    CmbBoxTovara.SelectedValuePath = "ID_товара";            // Указывает, что значение выбранного элетента будет ID_товара
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }






        ////добавить
        //// Метод для загрузки данных в ComboBox (категории, пол, размеры, цвет, поставщики)
        //private void LoadComboBoxData()
        //{
        //    try
        //    {
        //        using (var context = new Enti5()) // Создает контекст для работы с БД
        //        {
        //            // Загружает данные для ComboBox
        //            CmbBoxTovara.ItemsSource = context.товары.ToList();
        //            CmbBoxSklad.ItemsSource = context.склад.ToList();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show($"Ошибка при загрузке данных для ComboBox: {ex.Message}");
        //    }
        //}

        private void TBoxKolichestvoTovara_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Проверяет, является ли введенный символ цифрой
            if (!Char.IsDigit(e.Text, 0))
            {
                // Если это не цифра, отменяет ввод
                e.Handled = true;
            }
        }

        // Обработчик кнопки для сохранения данных
        private void ButtonDobavTovarNaSklad_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(TBoxKolichestvoTovara.Text) || TBoxKolichestvoTovara.Text.Length > 3 || !TBoxKolichestvoTovara.Text.All(Char.IsDigit))
            {
                // Если введенные данные некорректны, выводим сообщение
                MessageBox.Show("Введите корректное количество товара (только цифры и не более 3 символов).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

           
            // Проверка на пустые поля
            string errorMessage = string.Empty;

            if (string.IsNullOrEmpty(TBoxKolichestvoTovara.Text)) errorMessage += "Колличество товара не заполнено.\n";
            
            if (CmbBoxTovara.SelectedItem == null) errorMessage += "ID товара не выбран.\n";
            if (CmbBoxSklad.SelectedItem == null) errorMessage += "ID склада не выбран.\n";
           

            // Если есть ошибки, выводим их
            if (!string.IsNullOrEmpty(errorMessage))
            {
                MessageBox.Show($"Пожалуйста, заполните все поля:\n{errorMessage}");
                return;
            }


            // Если все поля заполнены, создает новый объект для добавления в БД
            try
            {
                using (var context = new Enti5())
                {
                    // Создает новый товар и заполняет его данными
                    var newTovar = new товары_на_складе
                    {
                        колличество_товара = (int)Convert.ToDecimal(TBoxKolichestvoTovara.Text),

                        ID_склада = ((склад)CmbBoxSklad.SelectedItem).ID_склада,
                        ID_товара = ((товары)CmbBoxTovara.SelectedItem).ID_товара
                    };

                    // Добавляет товар в контекст и сохраняет изменения
                    context.товары_на_складе.Add(newTovar);
                    context.SaveChanges();
                }

                // Закрывает текущее окно и открывает окно с товаром
                Sklad DobavTovar = new Sklad();
                DobavTovar.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки при добавлении товара
                MessageBox.Show($"Ошибка при добавлении товара: {ex.Message}");
            }
        }




        private void ButtonDeleteTovarNaSklad_Click(object sender, RoutedEventArgs e)
        {
            var row = DtGrdSklad.SelectedItem as товары_на_складе;
            if (row == null)
            {
                MessageBox.Show("Необходимо выбрать строку для удаления");
                return;
            }
            MessageBoxResult result = MessageBox.Show("Вы точно хотите удалить?", "Dell", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                Enti5.товары_на_складе.Remove(row);
                Enti5.SaveChanges();
                DtGrdSklad.ItemsSource = Enti5.товары_на_складе.ToList();
            }
        }



        //переход на окно Главная
        private void LabelGlavnaya_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Glavnaya Glavnaya = new Glavnaya();
            Glavnaya.Show();
            this.Close();
        }


        //переход на окно товары
        private void LabelTovari_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tovari Glavnaya = new Tovari();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Инвентаризация
        private void LabelInventariz_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Inventarizatsiya Glavnaya = new Inventarizatsiya();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Поставщики
        private void LabelPostavshiki_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Postavshiki Glavnaya = new Postavshiki();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Склад
        private void LabelSklad_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Sklad Glavnaya = new Sklad();
            Glavnaya.Show();
            this.Close();
        }

        
    }
}
