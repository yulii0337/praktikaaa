﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для Postavshiki_two.xaml
    /// </summary>
    public partial class Postavshiki_two : Window
    {
        Enti5 database = new Enti5();
        public Postavshiki_two()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();
            DtGrdPostavki.ItemsSource = Enti5.поставщики.ToList();
            // загружает все данные при запуске приложения, чтобы сразу отображались в DataGrid.
            LoadData();

        }

        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }

        private Enti5 Enti5;

        //переход на окно Главная
        private void LabelGlavnaya_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Glavnaya_two Glavnaya_two = new Glavnaya_two();
            Glavnaya_two.Show();
            this.Close();
        }


        //переход на окно товары два
        private void LabelSotrudnik_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Sotrudniki Sotrudniki = new Sotrudniki();
            Sotrudniki.Show();
            this.Close();
        }



        //переход на окно Поставщики два
        private void LabelPostavshiki_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Postavshiki_two Postavshiki_two = new Postavshiki_two();
            Postavshiki_two.Show();
            this.Close();
        }

        // Метод для загрузки всех данных в DataGrid
        private void LoadData()
        {
            // загружает все поставщиков из базы данных (вместо "Enti5Entities.Instance.Поставщики" используйте свой контекст)
            DtGrdPostavki.ItemsSource = Enti5.поставщики.ToList();
        }

        // Обработчик для кнопки поиска
        private void BttnSearch_Click(object sender, RoutedEventArgs e)
        {
            // Получает текст из TextBox и приводим к нижнему регистру для нечувствительности к регистру
            string searchText = TBSearch.Text.ToLower();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                // Если текст пустой или состоит только из пробелов, загружает все данные
                LoadData();
            }
            else
            {
                // Если текст есть, выполняем поиск по всем указанным полям
                var filteredData = Enti5.поставщики
                    .Where(p => p.ID_поставщиков.ToString().ToLower().Contains(searchText) ||  // Поиск по ID поставщика
                                p.наименование_поставщика.ToLower().Contains(searchText) || // Поиск по наименованию поставщика
                                p.почта.ToLower().Contains(searchText) || // Поиск по почте
                                p.номер_телефона.ToLower().Contains(searchText) || // Поиск по номеру телефона
                                p.адрес.страна.ToLower().Contains(searchText) || // Поиск по стране
                                p.адрес.город.ToLower().Contains(searchText) || // Поиск по городу
                                p.адрес.улица.ToLower().Contains(searchText) || // Поиск по улице
                                p.адрес.дом.ToLower().Contains(searchText) || // Поиск по дому
                                p.фамилия.ToLower().Contains(searchText) || // Поиск по фамилии
                                p.имя.ToLower().Contains(searchText) || // Поиск по имени
                                p.отчество.ToLower().Contains(searchText) || // Поиск по отчеству
                                p.ИНН.ToLower().Contains(searchText)) // Поиск по ИНН
                    .ToList(); // Преобразуем результат в список

                // Обновляет ItemsSource для DataGrid с отфильтрованными данными
                DtGrdPostavki.ItemsSource = filteredData;
            }
        }
        //переход на окно Добавить поставщика
        private void LabelDobavPostsvchika_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            NewPostavchik Glavnaya = new NewPostavchik();
            Glavnaya.Show();
            this.Close();
        }
    }
}
