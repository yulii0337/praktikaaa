﻿using CaptchaGen;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string _captchaText; // Текст для капчи
        public MainWindow()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            GenerateCaptcha(); // Генерация капчи при загрузке окна
        }


        public DataTable Select(string selectSQL)
        {
            DataTable dataTable = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }

        // Метод для генерации CAPTCHA
        private void GenerateCaptcha()
        {
            _captchaText = GenerateRandomText(6);
            var captchaImageStream = ImageFactory.GenerateImage(_captchaText, 150, 400, 35);

            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.StreamSource = captchaImageStream;
            bitmap.EndInit();
            CaptchaImage.Source = bitmap;

        }
        private string GenerateRandomText(int length)
        {
            //ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789
            var random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void BtnRefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {

            // Проверяет что выбрана роль
            if (CmbBoxRole.SelectedItem == null)
            {
                MessageBox.Show("Выберите роль: Сотрудник или Администратор.");
                return;
            }

            string captchaInput = TxtBxCaptcha.Text;

            //проверка каптча
            if (captchaInput != _captchaText)
            {
                MessageBox.Show("Неврная каптча. Попробуйте снова.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                GenerateCaptcha();
                return;
            }

            // Проверяет что логин и пароль не пустые
            if (string.IsNullOrEmpty(TxtBxLogin.Text) || string.IsNullOrEmpty(TxtBxPas.Password))
            {
                MessageBox.Show("Введите логин и пароль.");
                return;
            }

            // Получает выбранную роль из ComboBox
            string selectedRole = ((ComboBoxItem)CmbBoxRole.SelectedItem).Content.ToString();

            // Использует Entity Framework для проверки аутентификации
            using (var context = new SkladEnn4()) // Контекст базы данных
            {
                if (selectedRole == "Сотрудник") // Если выбран Сотрудник
                {
                    // Ищет сотрудника по логину и паролю
                    var employeeAuth = context.аунтификация_сотрудника
                                            .Join(context.сотрудник,
                                                  auth => auth.ID_сотрудник,
                                                  emp => emp.ID_сотрудник,
                                                  (auth, emp) => new { emp, auth })
                                            .Where(a => a.auth.логин == TxtBxLogin.Text && a.auth.пароль == TxtBxPas.Password)
                                            .FirstOrDefault();

                    if (employeeAuth != null) // Если сотрудник найден
                    {

                        Glavnaya Glavnaya = new Glavnaya();
                        Glavnaya.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль для сотрудника.");
                    }
                }
                else if (selectedRole == "Администратор") // Если выбран Администратор
                {
                    // Ищет администратора по логину и паролю
                    var adminAuth = context.аунтификация_администратора
                                          .Join(context.администратор,
                                                auth => auth.ID_админ,
                                                admin => admin.ID_админ,
                                                (auth, admin) => new { admin, auth })
                                          .Where(a => a.auth.логин == TxtBxLogin.Text && a.auth.пароль == TxtBxPas.Password)
                                          .FirstOrDefault();

                    if (adminAuth != null) // Если администратор найден
                    {
                        // Открывает окно для администратора
                        Glavnaya_two adminWindow = new Glavnaya_two();
                        adminWindow.Show();
                        this.Close(); // Закрывает окно авторизации
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль для администратора.");
                    }
                }
                else
                {
                    MessageBox.Show("Выберите роль (Сотрудник или Администратор).");
                }

            }
        }
    }
}
