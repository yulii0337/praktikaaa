﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для Inventarizatsiya.xaml
    /// </summary>
    public partial class Inventarizatsiya : Window
    {

        Enti5 database = new Enti5();

        int selectRow;

        public Inventarizatsiya()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();
            DtGrdInventariz.ItemsSource = Enti5.инвентаризация_склада.ToList();

            // Загружает данные в DataGrid при открытии окна
            //LoadDataToDataGrid(); 
            DataToDataGrid(); // Загружает все данные при запуске окна
        }

        // Метод для загрузки данных в DataGrid
        private void DataToDataGrid()
        {
            try
            {
                using (var context = new Enti5()) // Создает контекст подключения к БД
                {
                    // Получаем все записи из таблицы Инвентаризация_склада с необходимыми связанными данными
                    var data = context.инвентаризация_склада
                                      .Include(i => i.товары)     // Загружает связанные данные с таблицей Товары
                                      .Include(i => i.склад)      // Загружает связанные данные с таблицей Склад
                                      .Include(i => i.сотрудник)  // Загружает связанные данные с таблицей Сотрудники
                                      .ToList();  // Преобразуем в список

                    // Привязываем результат к DataGrid
                    DtGrdInventariz.ItemsSource = data;
                }
            }
            catch (Exception ex)
            {
                // Обрабатываем ошибки при загрузке данных
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        // Обработчик нажатия кнопки поиска
        private void BttnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchQuery = TBSearch.Text.ToLower(); // Получаем текст поиска и преобразуем в нижний регистр

            try
            {
                using (var context = new Enti5()) // Создает контекст подключения к БД
                {
                    // Выполняет запрос для фильтрации данных по поисковому запросу
                    var filteredData = context.инвентаризация_склада
                                              .Include(i => i.товары)     // Загружает связанные данные с таблицей Товары
                                              .Include(i => i.склад)      // Загружает связанные данные с таблицей Склад
                                              .Include(i => i.сотрудник)  // Загружает связанные данные с таблицей Сотрудники
                                              .Where(i => i.дата_инвентаризации.ToString().Contains(searchQuery) ||  // Поиск по дате инвентаризации
                                                          i.склад.наименование.ToLower().Contains(searchQuery) ||  // Поиск по наименованию склада
                                                          i.товары.ID_товара.ToString().Contains(searchQuery) ||   // Поиск по коду товара
                                                          i.расчетный_остаток.ToString().Contains(searchQuery) ||  // Поиск по расчетному остатку
                                                          i.фактический_остаток.ToString().Contains(searchQuery) || // Поиск по фактическому остатку
                                                          i.сотрудник.фамилия.ToLower().Contains(searchQuery) ||   // Поиск по фамилии сотрудника
                                                          i.сотрудник.имя.ToLower().Contains(searchQuery) ||       // Поиск по имени сотрудника
                                                          i.сотрудник.отчество.ToLower().Contains(searchQuery))    // Поиск по отчеству сотрудника
                                              .ToList(); // Преобразуем в список

                    // Привязываеи результат фильтрации к DataGrid
                    DtGrdInventariz.ItemsSource = filteredData;
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки при фильтрации
                MessageBox.Show($"Ошибка при поиске данных: {ex.Message}");
            }
        }




        public DataTable Select(string selectSQL)
        {
            DataTable dataTable = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }

        private Enti5 Enti5;


        //переход на окно Главная
        private void LabelGlavnaya_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Glavnaya Glavnaya = new Glavnaya();
            Glavnaya.Show();
            this.Close();
        }


        //переход на окно товары
        private void LabelTovari_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tovari Glavnaya = new Tovari();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Инвентаризация
        private void LabelInventariz_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Inventarizatsiya Glavnaya = new Inventarizatsiya();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Поставщики
        private void LabelPostavshiki_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Postavshiki Glavnaya = new Postavshiki();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Склад
        private void LabelSklad_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Sklad Glavnaya = new Sklad();
            Glavnaya.Show();
            this.Close();
        }


        //переход на окно Добавить инвентаризацию
        private void LabelDobavNewTovar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            NewInventariz Glavnaya = new NewInventariz();
            Glavnaya.Show();
            this.Close();

        }

        private Enti5 GetDatabase()
        {
            return database;
        }
   

    }
}
