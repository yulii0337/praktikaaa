﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для Tovari.xaml
    /// </summary>
    public partial class Tovari : Window
    {
        Enti5 database = new Enti5();

        //Складской_учет_одеждыEntities cont = new Складской_учет_одеждыEntities();
        public Tovari()
        {
            InitializeComponent();
            //Складской_учет_одеждыEntities = new Складской_учет_одеждыEntities();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();
            DtGrdTovari.ItemsSource = Enti5.товары.ToList();
            LoadDataGridTov();  // Загружает все данные в DataGrid при запуске программы
        }

        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }


        private Enti5 Enti5;

        //private Складской_учет_одеждыEntities Складской_учет_одеждыEntities;
        //переход на окно Главная
        private void LabelGlavnaya_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Glavnaya Glavnaya = new Glavnaya();
            Glavnaya.Show();
            this.Close();
        }


        //переход на окно товары
        private void LabelTovari_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tovari Glavnaya = new Tovari();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Инвентаризация
        private void LabelInventariz_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Inventarizatsiya Glavnaya = new Inventarizatsiya();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Поставщики
        private void LabelPostavshiki_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Postavshiki Glavnaya = new Postavshiki();
            Glavnaya.Show();
            this.Close();
        }



        //переход на окно Добавить товар
        private void LabelDobavNewTovar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DobavTovar Glavnaya = new DobavTovar();
            Glavnaya.Show();
            this.Close();
        }

        //переход на окно Склад
        private void LabelSklad_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Sklad Glavnaya = new Sklad();
            Glavnaya.Show();
            this.Close();
        }



        // Метод для загрузки всех данных в DataGrid
        private void LoadDataGridTov()
        {
            try
            {
                using (var context = new Enti5()) // Создает контекст для работы с БД
                {
                    var allItems = context.товары
                        .Include("категория_товара")  // Подключает связанные таблицы (например, категория товара)
                        .Include("пол")              // Подключает пол
                        .Include("размеры")          // Подключает размеры
                        .Include("цвет")             // Подключает цвет
                        .Include("поставщики")       // Подключает поставщиков
                        .ToList();

                    DtGrdTovari.ItemsSource = allItems;  // Устанавливает исходные данные для DataGrid
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        // Обработчик кнопки для поиска данных
        private void BttnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchQuery = TBSearch.Text.ToLower();  // Получает текст из TextBox для поиска

            // Если текст в поисковом поле пустой, просто показывает все данные
            if (string.IsNullOrEmpty(searchQuery))
            {
                LoadDataGridTov();
                return;
            }

            try
            {
                using (var context = new Enti5()) // Создает контекст для работы с БД
                {
                    // Фильтрует данные на основе запроса поиска
                    var filteredItems = context.товары
                        .Include("категория_товара")  // Подключает связанные таблицы (например, категория товара)
                        .Include("пол")              // Подключает пол
                        .Include("размеры")          // Подключает размеры
                        .Include("цвет")             // Подключает цвет
                        .Include("поставщики")       // Подключает поставщиков
                        .Where(t => t.ID_товара.ToString().Contains(searchQuery) ||  // Поиск по ID товара
                                    t.артикул.Contains(searchQuery) ||            // Поиск по артикулу
                                    t.наименование_товара.Contains(searchQuery) || // Поиск по наименованию товара
                                    t.категория_товара.наименование.Contains(searchQuery) || // Поиск по категории
                                    t.пол.наименование.Contains(searchQuery) ||   // Поиск по полу
                                    t.размеры.европейский.ToString().Contains(searchQuery) || // Поиск по европейскому размеру
                                    t.размеры.российский.ToString().Contains(searchQuery) ||  // Поиск по российскому размеру
                                    t.цвет.наименование.Contains(searchQuery) ||   // Поиск по цвету
                                    t.цена.ToString().Contains(searchQuery) ||      // Поиск по цене
                                    t.состав.Contains(searchQuery) ||               // Поиск по составу
                                    t.поставщики.ID_поставщиков.ToString().Contains(searchQuery)) // Поиск по ID поставщика
                        .ToList();

                    DtGrdTovari.ItemsSource = filteredItems;  // Устанавливает отфильтрованные данные для DataGrid
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выполнении поиска: {ex.Message}");
            }
        }

    }
}
