﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using Microsoft.Office.Interop.Word;
using Application = Microsoft.Office.Interop.Word.Application;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для NewInventariz.xaml
    /// </summary>
    public partial class NewInventariz
    {

        Enti5 database = new Enti5();

        public NewInventariz(/*Entities_Sklad_tovar Entities_Sklad_tovar, категория_товара pr*/)
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();

            //// Вызов метода для загрузки данных в ComboBox товары
            TovariToComboBox();

            // Вызов метода для загрузки данных в ComboBox склада
            SkladTovariToComboBox();

            // Вызов метода для загрузки данных в ComboBox сотрудникков
            SotrudnikToComboBox();

         

        }

        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }

        private Enti5 Enti5;



        //// Метод для загрузки данных из БД в ComboBox товары
        private void TovariToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблицы 'товары'
                using (var context = new Enti5 ())  // Enti5 - это ваш контекст данных
                {
                    // Выполняет запрос только по таблице 'товары' без соединений с другими таблицами
                    var tovari = context.товары         // Берет все товары из таблицы 'товары'
                        .Distinct() //удаляет дублирующиеся записи
                                .ToList();           // Преобразует в список

                    // Привязывает список товаров к ComboBox
                    CmbBoxTovar.ItemsSource = tovari;       // Устанавливает источник данных для ComboBox
                    CmbBoxTovar.DisplayMemberPath = "артикул"; // Указывает, что в ComboBox будет отображаться поле 'наименование_товара'
                    CmbBoxTovar.SelectedValuePath = "ID_товара";           // Указывает, что значение выбранного элетента будет 'ID_товара'
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }



        // Метод для загрузки данных из БД в ComboBox склад
        private void SkladTovariToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц
                using (var contexti = new Enti5())  // Enti5 - это ваш контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'инвентаризация_склада' и 'склада' по ID_склада
                    var skladi = contexti.склад
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование склада
                    CmbBoxSklad.ItemsSource = skladi;    // Устанавливает источник данных
                    CmbBoxSklad.DisplayMemberPath = "наименование";  // Указывает, что в ComboBox будет отображаться наименование склада
                    CmbBoxSklad.SelectedValuePath = "ID_склада";            // Указывает, что значение выбранного элетента будет ID_склада
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }



        // Метод для загрузки данных из БД в ComboBox сотрудник
        private void SotrudnikToComboBox()
        {
            try
            {
                // Подключается к Entity Framework и получает данные из таблиц инвентаризация_склада
                using (var contextik = new Enti5())  // Enti5 - это ваш контекст данных
                {
                    // Выполняет запрос, соединяя таблицы 'инвентаризация_склада' и 'сотрудник' по ID_сотрудник
                    var Sotrud = contextik.сотрудник
                        .Distinct() //удаляет дублирующиеся записи
                        .ToList();             // Преобразует в список

                    // Привязывает список товаров к ComboBox, отображая только наименование сотрудника
                    CmbBoxSotrudnik.ItemsSource = Sotrud;    // Устанавливает источник данных
                    CmbBoxSotrudnik.DisplayMemberPath = "ID_сотрудник";  // Указывает, что в ComboBox будет отображаться наименование сотрудника
                    CmbBoxSotrudnik.SelectedValuePath = "ID_склада";            // Указывает, что значение выбранного элетента будет ID_сотрудник
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки подключения или выполнения запросов
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        //добавить
        // Обработчик нажатия кнопки регистрации данных
        private void RegistrBttn_Click(object sender, RoutedEventArgs e)
        {
            // Проверка, все ли данные введены
            string errorMessage = CheckData(); // Метод для проверки данных

            if (string.IsNullOrEmpty(errorMessage))
            {
                // Если данные введены корректно, сохраняет их в БД
                SaveDataToDatabase();
                
                Inventarizatsiya NewInventariz = new Inventarizatsiya();
                NewInventariz.Show();
                this.Close();
            }
            else
            {
                // Если данные не введены, показывает сообщение с ошибками
                MessageBox.Show($"Ошибка! {errorMessage}");
            }
        }

        // Метод для проверки введенных данных
        private string CheckData()
        {
            //для расчетный остаток ограничение
            if (string.IsNullOrEmpty(TextBxRachetOstatok.Text) || TextBxRachetOstatok.Text.Length > 8 || !TextBxRachetOstatok.Text.All(Char.IsDigit))
            {
                // Если введенные данные некорректны, выводит сообщение
                MessageBox.Show("Введите корректный расчетный остаток (только цифры и не более 8 символов).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            //для фактический остаток ограничение
            if (string.IsNullOrEmpty(TextBxFaktOstatok.Text) || TextBxFaktOstatok.Text.Length > 8 || !TextBxFaktOstatok.Text.All(Char.IsDigit))
            {
                // Если введенные данные некорректны, выводит сообщение
                MessageBox.Show("Введите корректный фактический остаток (только цифры и не более 8 символов).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            string errorMessage = "";

            // Проверяет, введена ли дата
            if (DatePicInventariz.SelectedDate == null)
                errorMessage += "Дата инвентаризации не выбрана.\n";

            // Проверяет, выбран ли товар
            if (CmbBoxTovar.SelectedItem == null)
                errorMessage += "Товар не выбран.\n";

            // Проверяет, выбран ли склад
            if (CmbBoxSklad.SelectedItem == null)
                errorMessage += "Склад не выбран.\n";

            // Проверяет, выбран ли сотрудник
            if (CmbBoxSotrudnik.SelectedItem == null)
                errorMessage += "Сотрудник не выбран.\n";

            // Проверяет, введен ли расчетный остаток
            if (string.IsNullOrWhiteSpace(TextBxRachetOstatok.Text))
                errorMessage += "Расчетный остаток не введен.\n";

            // Проверяет, введен ли фактический остаток
            if (string.IsNullOrWhiteSpace(TextBxFaktOstatok.Text))
                errorMessage += "Фактический остаток не введен.\n";

            return errorMessage;
        }

        // Метод для сохранения данных в БД
        private void SaveDataToDatabase()
        {
            try
            {
                using (var context = new Enti5())  // Создает контекст подключения к БД
                {
                    // Создает новый объект инвентаризации
                    var newInventariz = new инвентаризация_склада
                    {
                        дата_инвентаризации = DatePicInventariz.SelectedDate.Value, // Дата инвентаризации из DatePicker
                        ID_склада = (CmbBoxSklad.SelectedItem as склад).ID_склада,  // ID склада из ComboBox
                        ID_товара = (CmbBoxTovar.SelectedItem as товары).ID_товара,  // ID товара из ComboBox
                        расчетный_остаток = (int)Convert.ToDecimal(TextBxRachetOstatok.Text), // Расчетный остаток из TextBox
                        фактический_остаток = (int)Convert.ToDecimal(TextBxFaktOstatok.Text), // Фактический остаток из TextBox
                        ID_сотрудник = (CmbBoxSotrudnik.SelectedItem as сотрудник).ID_сотрудник // ID сотрудника из ComboBox
                    };

                    // Добавляет новый объект в таблицу инвентаризаций
                    context.инвентаризация_склада.Add(newInventariz);

                    // Сохраняет изменения в базе данных
                    context.SaveChanges();

                    // Показывает сообщение об успешном добавлении
                    MessageBox.Show("Данные успешно сохранены!");
                }
            }
            catch (Exception ex)
            {
                // Обрабатывает ошибки при сохранении
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }
        }

        //назад


        private void NazadBttn_Click_1(object sender, RoutedEventArgs e)
        {
            Inventarizatsiya NewInventariz = new Inventarizatsiya();
            NewInventariz.Show();
            this.Close();
        }


        private void SozdatOtchetBttn_Click(object sender, RoutedEventArgs e)
        {
            //Дата инвентаризации
            string textToExport = DatePicInventariz.Text;

            //Склад
            string textToExport1 = CmbBoxSklad.Text;

            //Товар
            string textToExport2 = CmbBoxTovar.Text;

            //Сотрудник
            string textToExport3 = CmbBoxSotrudnik.Text;

            //Расчетный остаток
            string textToExport5 = TextBxRachetOstatok.Text;

            //Фактический остаток
            string textToExport6 = TextBxFaktOstatok.Text;



            if (string.IsNullOrEmpty(textToExport))
            {
                MessageBox.Show("Введите текст для экспорта", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                //Microsoft.Office.Interop.Word
                Application wordApp = new Application();
                Document wordDoc = wordApp.Documents.Add();
                wordDoc.Content.Text =
                    $"                                      Основная информация: \n\n " +
                    $"Дата инвентаризации: {DatePicInventariz.Text} " +
                    $"Склад: {CmbBoxSklad.Text}\n " +
                    $"Товар: {CmbBoxTovar.Text}\n " +
                    $"Сотрудник: {CmbBoxSotrudnik.Text}\n " +
                    $"Инвентаризация: \n\n " +
                    $"Расчетный остаток: {TextBxRachetOstatok.Text}\n" +
                    $"Фактический остаток: {TextBxFaktOstatok.Text}\n ";

                string filePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\ExportedDocument.docx";
                wordDoc.SaveAs2(filePath);
                wordDoc.Close();
                wordApp.Quit();

                MessageBox.Show($"Документ успешно сохраён: {filePath}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте в Word: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


    }
}
