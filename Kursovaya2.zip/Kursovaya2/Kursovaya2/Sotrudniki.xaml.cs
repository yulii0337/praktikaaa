﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kursovaya2
{
    /// <summary>
    /// Логика взаимодействия для Sotrudniki.xaml
    /// </summary>
    public partial class Sotrudniki : Window
    {
        Enti5 database = new Enti5();

        public Sotrudniki()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            Enti5 = new Enti5();

            DtGrdSotrudniki.ItemsSource = Enti5.сотрудник.ToList(); 
            //LoadDataGridSotrud();  // Загружает все данные в DataGrid при запуске программы

        }
        private Enti5 Enti5;
        public System.Data.DataTable Select(string selectSQL)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable();
            SqlConnection sqlConnection = new SqlConnection(@"data source=DESKTOP-M6BHTCC;initial catalog=Складской_учет_одежды;integrated security=True;trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);
            dataAdapter.Fill(dataTable);
            return dataTable;
        }


        
        //ДОБАВЛЕНИЕ

        private void ButtonDobavSotrudnika_Click(object sender, RoutedEventArgs e)
        {

            // Проверка, что все обязательные поля заполнены
            if (string.IsNullOrEmpty(TxtBoxFamilia.Text) || 
                string.IsNullOrEmpty(TxtBoxName.Text) || 
                string.IsNullOrEmpty(TxtBoxOtchestvo.Text) ||
                string.IsNullOrEmpty(TxtBoxNumberTelefon.Text) || 
                string.IsNullOrEmpty(TxtBoxLogin.Text) || 
                string.IsNullOrEmpty(TxtBoxParol.Password) ||
                DatePicDRSotrudnik.SelectedDate == null)
            {
                MessageBox.Show("Все поля должны быть заполнены.");
                return;
            }

            // Проверка на корректность номера телефона
            if (TxtBoxNumberTelefon.Text.Length != 11 || !TxtBoxNumberTelefon.Text.All(char.IsDigit))
            {
                MessageBox.Show("Номер телефона должен содержать ровно 11 цифр.");
                return;
            }

            // Проверка на уникальность ФИО, дата рождения и номер телефона
            using (var context = new Enti5()) // подключаеься к контексту базы данных
            {
                var existingEmployee = context.сотрудник
                    .Where(s => 
                       s.фамилия == TxtBoxFamilia.Text 
                    && s.имя == TxtBoxName.Text 
                    && s.отчество == TxtBoxOtchestvo.Text
                    && s.дата_рождения == DatePicDRSotrudnik.SelectedDate.Value 
                    && s.номер_телефона == TxtBoxNumberTelefon.Text)
                    .FirstOrDefault(); // ищет сотрудника с такими данными

                if (existingEmployee != null) // Если сотрудник найден
                {
                    MessageBox.Show("Сотрудник с такими данными уже существует.");
                    return;
                }

                // Проверка на уникальность номера телефона
                var existingPhone = context.сотрудник
                    .Where(s => s.номер_телефона == TxtBoxNumberTelefon.Text)
                    .FirstOrDefault();

                if (existingPhone != null)
                {
                    MessageBox.Show("Номер телефона уже используется.");
                    return;
                }

                // Проверка на уникальность логина
                var existingLogin = context.аунтификация_сотрудника
                    .Where(a => a.логин == TxtBoxLogin.Text)
                    .FirstOrDefault();

                if (existingLogin != null)
                {
                    MessageBox.Show("Этот логин уже занят.");
                    return;
                }

                // Если все проверки прошли успешно, сохраняет данные в базу
                var newEmployee = new сотрудник
                {
                    фамилия = TxtBoxFamilia.Text,
                    имя = TxtBoxName.Text,
                    отчество = TxtBoxOtchestvo.Text,
                    дата_рождения = DatePicDRSotrudnik.SelectedDate.Value,
                    номер_телефона = TxtBoxNumberTelefon.Text
                };

                context.сотрудник.Add(newEmployee); // добавляем нового сотрудника

                // Создает аутентификацию для сотрудника
                var newAuth = new аунтификация_сотрудника
                {
                    ID_сотрудник = newEmployee.ID_сотрудник, // присваиваем ID нового сотрудника
                    логин = TxtBoxLogin.Text,
                    пароль = TxtBoxParol.Password
                };

                context.аунтификация_сотрудника.Add(newAuth); // добавляем аутентификацию

                // сохраняет изменения в базе данных
                context.SaveChanges();

                MessageBox.Show("Сотрудник успешно добавлен.");


                Sotrudniki Glavnaya_two = new Sotrudniki();
                Glavnaya_two.Show();
                this.Close();
            }
        }







        //переход на окно Главная
        private void LabelGlavnaya_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Glavnaya_two Glavnaya_two = new Glavnaya_two();
            Glavnaya_two.Show();
            this.Close();
        }


        //переход на окно товары два
        private void LabelSotrudnik_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Sotrudniki Sotrudniki = new Sotrudniki();
            Sotrudniki.Show();
            this.Close();
        }



        //переход на окно Поставщики два
        private void LabelPostavshiki_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Postavshiki_two Postavshiki_two = new Postavshiki_two();
            Postavshiki_two.Show();
            this.Close();
        }


    }
}
